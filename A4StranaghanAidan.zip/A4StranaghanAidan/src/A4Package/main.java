package A4Package;

import javax.swing.JOptionPane;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int currAnswer = JOptionPane.showConfirmDialog(null,
				"Would you like to play 20 Questions",
				"20 Questions",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		Questioner questioner = new Questioner();
		while (currAnswer == JOptionPane.YES_OPTION) {
		questioner.playRound();
		currAnswer = JOptionPane.showConfirmDialog(null,
				"Would you like to play again? I get better every round",
				"20 Questions",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
			}
		questioner.writeTree();
		}
	}
