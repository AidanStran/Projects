package A4Package;

import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

public class Questioner {
	DTNode root;

	private class DTNode {
		   
		String value;
	    DTNode left;
	    DTNode right;
	    
	    
	    DTNode(String value){
	        this.value = value;
	        right = null;
	        left = null;
	    }
	    
	    DTNode(String value, DTNode yes, DTNode no){
	    	this.value = value;
	    	this.right = no;
	    	this.left = yes;
	    }
	    
	    boolean isLeaf() {
	     if (left == null|| right == null) {
	    	 return true;
	     	}
	     return false;
	    }
	 }
	
	Questioner(){
		root = new DTNode("Is it an animal?"); // root
		DTNode y1 = new DTNode("Is it a mammal?"); // first yes
		DTNode n1 = new DTNode("Is it a plant?"); // first no
		root.left = y1;
		root.right = n1;
		DTNode L1 = new DTNode("Human");
		DTNode L2 = new DTNode("shark");
		DTNode L3 = new DTNode("carrot");
		DTNode L4 = new DTNode("diamond");
		y1.left = L1;
		y1.right = L2;
		n1.left = L3;
		n1.right = L4;
		
		
	}

	
	public void playRound(){
		if(root == null) {
			
			return;	
		}
		DTNode walk = root;
		DTNode walkPrev = null;
		while (!walk.isLeaf()) {
			int currAnswer = JOptionPane.showConfirmDialog(null,
			"" + walk.value,
			"20 Questions",
			JOptionPane.YES_NO_OPTION,
			JOptionPane.QUESTION_MESSAGE);
		if (currAnswer == JOptionPane.YES_OPTION) {
			walkPrev = walk;
			walk = walk.left;
			}
		else if (currAnswer == JOptionPane.NO_OPTION) {
			walkPrev = walk;
			walk = walk.right;
			}
		
		}
		int currAnswer = JOptionPane.showConfirmDialog(null,
				"Are you thinking of a / an " + walk.value,
				"20 Questions",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		if(currAnswer == JOptionPane.YES_OPTION){
			JOptionPane.showMessageDialog(null, "You've guessed correctly, well done", "WINNER!", JOptionPane.PLAIN_MESSAGE);
			}
		else if (currAnswer == JOptionPane.NO_OPTION) {
			String newAnswer = JOptionPane.showInputDialog("What were you thinking of");
			String newQuestion = JOptionPane.showInputDialog("What is a question that distinguish what you were thinking of?");
			
			DTNode newQuestNode = new DTNode(newQuestion);
			DTNode newAnswerNode = new DTNode(newAnswer);
			
			walkPrev.left = newQuestNode;
			newQuestNode.left = newAnswerNode;
			newQuestNode.right = walk;
			}
	}
	
	public void writeTree() {
		String newTxtFile = JOptionPane.showInputDialog("What would you like the name of your gamefile to be saved to?");
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(newTxtFile + ".txt"));
			writeTreeHelper(root, writer);
			writer.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	private void writeTreeHelper(DTNode node, BufferedWriter writer) {
		if (node != null) {
			try {
				if(!node.isLeaf()) {
				writer.write("< " + node.value + "\n");
				}
				else {
					
					writer.write("< " + node.value + "\n> \n");
					}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		writeTreeHelper(node.left, writer);
		writeTreeHelper(node.right, writer);
		}
	}


	public void readTree() {
		
	}

	
}