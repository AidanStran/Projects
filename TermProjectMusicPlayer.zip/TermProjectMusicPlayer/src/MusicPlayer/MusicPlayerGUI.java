package MusicPlayer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class MusicPlayerGUI implements ActionListener {

	JFrame frame;
	JTextField textField;
	JButton[] actions = new JButton[2];
	JButton next, back, dequeueButton, searchButton, songList;
	JLabel songplaying, album, artist, duration, awardWinning;
	JPanel panel;
	
	Font myFont = new Font("bold", Font.BOLD, 30);

	MusicPlayer mp = new MusicPlayer();
	
	MusicPlayerGUI(MusicPlayer mp){
		this.mp = mp;
		frame = new JFrame("Music Player");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 600);
		frame.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(50, 25, 380, 50);
		textField.setText("            Current Song");
		textField.setFont(myFont);
		textField.setEditable(false);

		dequeueButton = new JButton("Remove from Queue");
		dequeueButton.addActionListener(this);
		searchButton = new JButton("Search");

		actions[1] = dequeueButton;
		//actions[2] = searchButton;

		dequeueButton.setBounds(300,500,150,50);

		songplaying = new JLabel("Song Playing: ");

		album = new JLabel("Album: ");

		artist = new JLabel("Artist: ");

		duration = new JLabel("Duration: ");

		awardWinning = new JLabel("Award Winning: ");

		songList = new JButton("List of songs");
		songList.addActionListener(this);
		songList.setActionCommand("listSongs");

		next = new JButton("Next");
		next.addActionListener(this);
		next.setActionCommand("next");

		back = new JButton("Prev");
		back.addActionListener(this);
		back.setActionCommand("back");

		panel = new JPanel();
		panel.setBounds(50, 100, 380, 300);
		panel.setLayout(new GridLayout(8, 2, 1, 1));
		panel.add(songplaying);
		panel.add(album);
		panel.add(artist);
		panel.add(duration);
		panel.add(awardWinning);
		panel.add(songList);
		panel.add(next);
		panel.add(back);
		
		frame.add(panel);
		frame.add(dequeueButton);
		//frame.add(searchButton);
		frame.add(textField);
		frame.setVisible(true);
		updateCurrentSongInfo(mp.getCurrentsong());
	}

	public void updateCurrentSongInfo(Data song){	
			songplaying.setText("Song Playing: " + song.getSongName());
			album.setText("Album: " + song.getAlbum());
			artist.setText("Artist: " + song.getArtist());
			duration.setText("Duration: " + song.getDuration());
			awardWinning.setText("Award Winning: " + song.getAwardWinning());
		panel.updateUI();
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if(cmd.equalsIgnoreCase("listSongs")){
			SongListGUI songList = new SongListGUI(mp);
		} else if(cmd.equalsIgnoreCase("next")){
			mp.nextSong();
			updateCurrentSongInfo(mp.getCurrentsong());
		} else if(cmd.equalsIgnoreCase("back")){
			mp.prevSong();
			updateCurrentSongInfo(mp.getCurrentsong());
		} else if(e.getSource()==dequeueButton) {
			mp.getQueue().dequeue();
		}
		
	}

}
