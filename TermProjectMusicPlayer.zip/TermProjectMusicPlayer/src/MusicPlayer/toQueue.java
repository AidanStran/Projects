package MusicPlayer;

import java.util.NoSuchElementException;

import javax.swing.JOptionPane;

class QNode {
    Data data;

    QNode next, prev;

    public QNode(Data data){
        this.data = data;
        this.next = null;
        this.prev = null;
    	}


}

    public class toQueue {
	QNode head;
	QNode tail;
	QNode root;
	int size;
	
	public toQueue() {
		this.head = null;
		this.tail = null;
	}
	
	void enqueue(Data data) {
		QNode temp = new QNode(data);
		
		if (tail == null) {
            head = this.tail = temp;
            return;
        	}	
		else {
		tail.next = temp;
        temp.prev = tail;
        tail = temp;
        }
	}
	
	void dequeue(){ // Dequeues the TAIL of the LL 
      if (isEmpty()) {
    	  JOptionPane.showMessageDialog(null, "There is no previous song", "alert", JOptionPane.ERROR_MESSAGE);
      }
      else {
        QNode temp = tail;
        tail = tail.prev;
 
        if (tail == null)
          head = null;
        else
          tail.next = null;
      }
    }
    
    private boolean isEmpty() {
    	return head == null;
	}

	public String printQueue() {
        String master = "";    
        QNode walk = head;
            while(walk != null){
                if(walk.data.getDuration() != "N/A") {
                	String out = "\n" + walk.data.getSongName();
                    master = master + out;
                }
                walk = walk.next;
            }
			return master;
        }

    
   }
    
    
   

