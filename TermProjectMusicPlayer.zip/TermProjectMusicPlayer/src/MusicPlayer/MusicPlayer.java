package MusicPlayer;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class MusicPlayer {

	ArrayList<Data> songs = new ArrayList<Data>();
	toQueue queueList = new toQueue();
	TernarySearchTree tst = new TernarySearchTree();
	//Set node to first song in queue
	String DisplayQueue;
	QNode node;
	
	public void init(){
		Scanner s;
		try {
			s = new Scanner(new File("songFile.txt"));
			while (s.hasNextLine()) {
				   String line = s.nextLine();
				   
				   String temp[] = line.split(",");
				   String songName = temp[0];
				   tst.insert(songName);
				   String album = temp[3];
				   String duration = temp[2];
				   String artist = temp[1];
				   boolean awardWinning = (1 == Integer.parseInt(temp[4]));
				   
				   Data data = new Data(songName, artist, duration, album, awardWinning);
				   
				   songs.add(data);
				}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		QNode dummy = new QNode(new Data("N/A", "N/A", "N/A", "N/A", false));
		queueList.head = dummy;
		queueList.tail = dummy;
		node = queueList.head;
	}
	
	public TernarySearchTree getTST() {
		return tst;
	}
	
	public void printSongs() {
		for(int i=0; i < songs.size(); i++) {
			System.out.println(songs.get(i));
		}
	}

	public Data getCurrentsong(){
		return node.data;
	}

	
	public void nextSong(){
		if(node == null ||node.next == null) {
			JOptionPane.showMessageDialog(null, "There is no next song", "alert", JOptionPane.ERROR_MESSAGE);
		}
		else{
			node = node.next;
			
		}
	}

	
	public void prevSong(){
		if (node.prev == null||node.prev.data.getDuration() == "N/A") {
			
			JOptionPane.showMessageDialog(null, "There is no previous song", "alert", JOptionPane.ERROR_MESSAGE);
		}
		else {node = node.prev;
		}
	}
	
	public ArrayList<Data> getSongList(){
		return songs;
	}
	
	
	public toQueue getQueue() {
		return queueList;
		
	}
	
}
