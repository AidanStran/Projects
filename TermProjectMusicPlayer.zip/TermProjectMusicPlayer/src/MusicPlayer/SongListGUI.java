package MusicPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class SongListGUI implements ActionListener{
	JFrame frame;
	JTextField textField;
	JPanel panel;
	JButton button;
	JButton searchButton;
	JLabel label;
	JLabel searchLabel;
	Font myFont = new Font("bold", Font.BOLD, 30);
	
	MusicPlayer mp = new MusicPlayer();
	TernarySearchTree tree = new TernarySearchTree();

	
	SongListGUI(MusicPlayer mp){
		this.mp = mp;
		frame = new JFrame("Song List");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(700, 1200);
		frame.setLayout(null);
		frame.setVisible(true);
		
		panel = new JPanel();
		panel.setBounds(100, 150, 500, 900);
		panel.setLayout(new GridLayout(4, 4, 10, 10));
		panel.setBackground(Color.GRAY);
		textField = new JTextField();
		textField.setBounds(100, 25, 500, 50);
		textField.setFont(myFont);
		textField.setEditable(true);
		searchButton = new JButton("Search");
		searchButton.setBounds(600, 25, 75, 50);
		searchButton.addActionListener(this);
		
		for(int i=0; i < mp.getSongList().size(); i++) {
		JLabel label = new JLabel(mp.getSongList().get(i).getSongName());
		JButton button = new JButton("Queue");
		JButton songinfo = new JButton("Info");
		button.addActionListener(this);
		button.setActionCommand("" + i);
		songinfo.addActionListener(this);
		songinfo.setActionCommand(i + "");
		label.setBounds(10,50*i,150,50);
		panel.add(label);
		songinfo.setBounds(200, 58*i, 80, 30);
		panel.add(songinfo);
		button.setBounds(270,58*i,100,30);
		panel.add(button);
		}
		
		//frame.add(searchLabel);
		frame.add(textField);
		frame.add(panel);
		frame.add(searchButton);
		
	}

	public void actionPerformed(ActionEvent e) {
		try {
			  int i = Integer.parseInt(e.getActionCommand());
			  Data song = mp.getSongList().get(i);
			  if(((JButton) e.getSource()).getText().equalsIgnoreCase("queue")){
					mp.getQueue().enqueue(song);
					JOptionPane.showConfirmDialog(null,
							"Songs in Queue: " + mp.getQueue().printQueue(),
							"Current Queue",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.PLAIN_MESSAGE);
				} else 
					if(((JButton) e.getSource()).getText().equalsIgnoreCase("Info")) { 
					JOptionPane.showConfirmDialog(null,
							"Song: " + song.getSongName() + "\nDuration: " + song.getDuration() +
									"\nAlbum: " + song.getAlbum() + "\nArtist: " + song.getArtist() +
									"\nAward Winning: " + song.getAwardWinning(),
							"Info",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.PLAIN_MESSAGE);
					}
					
				
			 } catch (NumberFormatException c) {
			  // actionCommand is not an integer
				if(e.getSource()==searchButton) {
					JOptionPane.showConfirmDialog(null,
							"If returns true, then song has been found with that prefix. Otherwise False. \nResult: " + mp.getTST().startsWith(textField.getText()),
							"Search Results",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.PLAIN_MESSAGE);
					}
			 }
		}
	}
