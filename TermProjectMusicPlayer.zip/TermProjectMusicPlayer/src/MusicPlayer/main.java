package MusicPlayer;

import java.util.List;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MusicPlayer mp3 = new MusicPlayer();
		mp3.init();
		TernarySearchTree tst = mp3.getTST();
		MusicPlayerGUI musicPlayerGUI = new MusicPlayerGUI(mp3);
		}
	}
		
 
