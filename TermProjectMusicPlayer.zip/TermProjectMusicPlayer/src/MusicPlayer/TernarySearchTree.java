package MusicPlayer;

class TSTNode {
    char val;
    TSTNode left, mid, right;
    boolean end;
    
    public TSTNode() {
        
    }
    
    public TSTNode(char val) {
        this.val = val;
    }
}

public class TernarySearchTree {
    TSTNode root;

    public TernarySearchTree() {
        root = new TSTNode();
    }

    public void insert(String word) {
        if (word != null && !word.isEmpty()) {
        	insertHelper(word, 0, root);
        }
    }
    
    private TSTNode insertHelper(String word, int index, TSTNode node) {
        char ch = word.charAt(index);
        if (node == null) {
        	node = new TSTNode(ch);
        	}
        if (ch < node.val) {
        	node.left = insertHelper(word, index, node.left);
        }
        else if (ch > node.val) {
        	node.right = insertHelper(word, index, node.right);
        }
        else if (index < word.length() - 1) {
        	node.mid = insertHelper(word, index + 1, node.mid);
        }
        else {
        	node.end = true;
        }
        return node;
    }

    public boolean startsWith(String prefix) {
        if (prefix == null || prefix.isEmpty()) {
        	return false;
        }
        return startsWithHelper(prefix, 0, root);
    }
    
    private boolean startsWithHelper(String prefix, int index, TSTNode node) {
        if (node == null) {
        	return false;
        }
        char ch = prefix.charAt(index);
        if (ch < node.val) {
        	return startsWithHelper(prefix, index, node.left);
        }
        if (ch > node.val) {
        	return startsWithHelper(prefix, index, node.right);
        }
        if (index == prefix.length() - 1) {
        	return true;
        }
        return startsWithHelper(prefix, index + 1, node.mid);
    }
}
