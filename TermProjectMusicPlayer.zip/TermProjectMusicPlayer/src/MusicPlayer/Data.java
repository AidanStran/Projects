package MusicPlayer;


public class Data {
	String songName;
	String duration;
	String artist;
	String album;
	boolean awardWinning;

	public Data(String songName, String duration, String artist, String album, boolean awardWinning) {
		this.songName = songName;
		this.duration = duration;
		this.artist = artist;
		this.album = album;
		this.awardWinning = awardWinning;
	}
	
	
	public String getSongName() {
		return songName;
		
	}
	public String getAlbum() {
		return album;
		
	}
	public String getArtist() {
		return artist;
		
	}
	public String getDuration() {
		return duration;
		
	}
	public boolean getAwardWinning() {
		return awardWinning;
		
	}


	
	
}


